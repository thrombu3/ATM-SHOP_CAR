<template>
    <div id="main" style="width: 1260px;height:400px;">SourceRate.vue</div>
</template>

<script>
    export default {
        name: "SourceRate",
        mounted() {

        }
    }
</script>

<style scoped>

</style>