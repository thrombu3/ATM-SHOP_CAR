export default {
    // base_url: 'http://127.0.0.1:8000/',
    // 跑局域网
    base_url: 'http://192.168.12.77:8000/',
    // 上线
    // base_url: 'http://101.200.207.212:8000/'
}