# 短信应用 SDK AppID
APPID = '你的APPID'  # SDK AppID 以1400开头
# 短信应用 SDK AppKey
APPKEY = "********"
# 短信模板ID，需要在短信控制台中申请
TEMPLATE_ID = '951401'  # NOTE: 这里的模板 ID`7839` 只是示例，真实的模板 ID 需要在短信控制台中申请
# 签名
SMS_SIGN = "爱山水的程序猿"  # NOTE: 签名参数使用的是`签名内容`，而不是`签名ID`。这里的签名"腾讯云"只是示例，真实的签名需要在短信控制台中申请