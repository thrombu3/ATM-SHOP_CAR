from django.apps import AppConfig


class AdministratorConfig(AppConfig):
    name = 'oldboy_exa.apps.administrator.administrator'
