from django.apps import AppConfig


class TeachersConfig(AppConfig):
    name = 'oldboy_exa.apps.teachers'
