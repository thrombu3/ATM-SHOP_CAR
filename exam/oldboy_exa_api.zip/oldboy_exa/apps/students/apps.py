from django.apps import AppConfig


class StudentsConfig(AppConfig):
    name = 'oldboy_exa.apps.students'
