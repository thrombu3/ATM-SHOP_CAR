# 缓存手机号的key
SMS_PHONE_CACHE='sms_cache_exa_%s'