# author:liu_ll
from celery import Celery
#在脚本中导入django环境
import os
import django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'oldboy_exa.settings.dev')
django.setup()

backend = 'redis://127.0.0.1:6379/2'
broker = 'redis://127.0.0.1:6379/3'
app = Celery(__name__, broker=broker, backend=backend,
             include=['oldboy_exa.apps.teachers.teacher_task']
             )

# 启动worker命令
# celery -A celery_task worker -l info -P eventlet
